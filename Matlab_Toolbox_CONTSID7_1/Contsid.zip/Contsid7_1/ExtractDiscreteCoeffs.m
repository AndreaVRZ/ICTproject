%function which extracts discrete time LPV coefficients with respect to the
%Continuous time ones.
%Bc must not have a delay. play on the input signal to express pure delay


