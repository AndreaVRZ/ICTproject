% f(u)=u+NL_H(2)*u.^2+NL_H(3)*u.^3;


