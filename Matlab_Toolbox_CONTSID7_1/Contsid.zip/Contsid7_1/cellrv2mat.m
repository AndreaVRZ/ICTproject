% CELLRV2MAT  Convert cell of row vectors into matrix. (Similar to the
% build-in function cell2mat.


