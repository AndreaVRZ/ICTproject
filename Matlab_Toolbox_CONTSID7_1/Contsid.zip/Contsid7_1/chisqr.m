%CHISQR	Random deviates from the chi-square distribution.
%	CHISQR(M,N,V) generates an MxN matrix of random deviates from
%	the chi-squared distribution on V degrees of freedom.
%	V must be a scalar.
%
%	See also CHISQP, CHISQQ.


