% nInput = length(model.InputNames);
% The line of code above has been modified by AP on 12/01/2015.


