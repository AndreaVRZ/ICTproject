%%%%%%%%%%% Discrete version of hsrivc %%%%%%%%%%%%%%%
%see hsrivc.m for help
% responsability : Vincent Laurain
% [Aes,Bes,fes,theta] = hsriv( y, u , [nF nB ordernl delay], maxIter,tol)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


