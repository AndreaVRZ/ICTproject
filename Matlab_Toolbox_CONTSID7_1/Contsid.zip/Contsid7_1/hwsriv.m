%   HWSRIV identification for discrete-time Hammerstein-Wiener model identification
%	by the Simplified Refined Instrumental Variable for OE model,
%	especially for initialization of HWSRIVC, type 'help hwsrivc'


