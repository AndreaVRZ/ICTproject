%    Mstd = std(M);


