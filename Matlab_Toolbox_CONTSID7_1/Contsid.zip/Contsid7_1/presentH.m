%% Function which displays usefull information about a idpoly generated
%% using hsrivc or hrivc


