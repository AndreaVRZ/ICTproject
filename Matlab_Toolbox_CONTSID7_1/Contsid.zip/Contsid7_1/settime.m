%	Settling Time at 99 % of a filtered system of A^2 or from the theta
%   form th (A^2 or F^2) (see help theta)
%	Use :
%	[Tr]	=	settime(A)
%	[Tr]	=	settime(idpoly)
%


