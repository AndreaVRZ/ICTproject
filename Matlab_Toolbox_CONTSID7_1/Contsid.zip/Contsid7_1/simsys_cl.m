% [Abar,Bbar,Cbar,T,k] = obsvf(M0_ss.A,M0_ss.B,M0_ss.C);


