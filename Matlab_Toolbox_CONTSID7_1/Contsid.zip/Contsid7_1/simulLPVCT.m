%stuff zeros at the beginning for simulation purposes:


