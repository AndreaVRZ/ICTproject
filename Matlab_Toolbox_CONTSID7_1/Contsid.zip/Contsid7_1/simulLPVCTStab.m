%%stuff of 0 data to avoid simulation problems


